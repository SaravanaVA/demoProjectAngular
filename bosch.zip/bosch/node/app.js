import 'express';


// body parser

// define port
let port = 3000;

// routing will goes here

res.listen('/save', ()=>{
    // save to db logic goes here
    // res.send()/
});

app.listenPort( port);