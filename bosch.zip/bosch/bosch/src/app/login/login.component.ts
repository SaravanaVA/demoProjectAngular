import { Component, OnInit } from '@angular/core';
import {FormBuilder,  Validators} from '@angular/forms';

import {HttpService} from '../shared/http.service'


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent {

constructor(private fb: FormBuilder, private http: HttpService ) { }

  public loginForm = this.fb.group({
    email: ['', [Validators.required, Validators.email]],
    password: ['', [Validators.required, Validators.minLength(4), Validators.maxLength(8)]]
  });

  public loginUser() {
      let email = localStorage.getItem('email');
      let password = localStorage.getItem('password');

      if(email === this.loginForm.value.email && password === this.loginForm.value.password) {
        alert('User logged in sucessfully');
        this.http.saveUser(this.loginForm.value);
      } else {
          alert('Invalid credentiails')
      }
  }  

}
