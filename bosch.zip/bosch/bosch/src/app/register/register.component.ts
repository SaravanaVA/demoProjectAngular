import { Component, OnInit } from '@angular/core';

import {Router} from '@angular/router'

import {FormBuilder,  Validators} from '@angular/forms'

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.scss']
})
export class RegisterComponent {



  constructor(private fb: FormBuilder, private router: Router) { }

   public registerForm = this.fb.group({
    firstName: ['', [Validators.required]],
    lastName: ['', Validators.required],
    email: ['', [Validators.required, Validators.email]],
    age: ['', [Validators.required, Validators.maxLength(2)]],
    password: ['', [Validators.required, Validators.minLength(4), Validators.maxLength(8)]]
})

public registerUser() {
    // console.log('my form value -->', this.registerForm.value);
    localStorage.clear();
    localStorage.setItem('email', this.registerForm.value.email)
    localStorage.setItem('password', this.registerForm.value.password)

    this.router.navigate(['login']);
    


    
}
 

}
