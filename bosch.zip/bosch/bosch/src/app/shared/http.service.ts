import { Injectable } from '@angular/core';

import { HttpClient } from '@angular/common/http';


@Injectable({
  providedIn: 'root'
})
export class HttpService {

  constructor(
    //   private http: HttpClient
      ) {   
   }

   public saveUser(userData: string) {
       let Url = 'http:localhost:3000/save';
    //    this.http.post(Url, userData);
   }
}
